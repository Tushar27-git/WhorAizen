#version 330 compatibility
layout(location = 0) out vec4 color;
void main() {
    color = vec4(0.0);
    discard;
}
